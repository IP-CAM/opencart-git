<?php
// Heading
$_['heading_title']     = '筛选';

// Text
$_['text_success']      = '成功： 您已成功更新筛选！';

// Column
$_['column_group']      = '筛选组';
$_['column_sort_order'] = '排序';
$_['column_action']     = '管理';

// Entry
$_['entry_group']       = '筛选组名称：';
$_['entry_name']        = '筛选名称：';
$_['entry_sort_order']  = '排序：';

// Error
$_['error_permission']  = '警告：您没有权限修改筛选组！';
$_['error_group']       = '警告：筛选组名必须为3到64个字符！';
$_['error_name']        = '警告：筛选名称必须为3到64个字符！';
?>