<?php
// Heading
$_['heading_title'] = '找不到页面！';

// Text
$_['text_not_found'] = '抱歉！ 无法找到您所请求的页面，请返回重试！';
?>