<?php
// Heading
$_['heading_title']     = '客户加盟佣金统计';

// Column
$_['column_affiliate']  = '加盟客户名';
$_['column_email']      = 'E-Mail';
$_['column_status']     = '状态';
$_['column_commission'] = '佣金';
$_['column_orders']     = '订单数量';
$_['column_total']      = '佣金总计';
$_['column_action']     = '管理';

// Entry
$_['entry_date_start']  = '开始日期：';
$_['entry_date_end']    = '结束日期：';
?>