<?php
// Heading
$_['heading_title']     = '在线客户';

// Text 
$_['text_guest']        = '游客';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = '顾客';
$_['column_url']        = '最近浏览页面';
$_['column_referer']    = '拓展自加盟客户';
$_['column_date_added'] = '最新日期';
$_['column_action']     = '管理';
?>